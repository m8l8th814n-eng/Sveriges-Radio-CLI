use anyhow::{Result, anyhow};
use cpal::traits::{DeviceTrait, HostTrait, StreamTrait};
use crossterm::event::{self, Event, KeyCode, KeyEventKind};
use ratatui::Terminal;
use ratatui::backend::CrosstermBackend;
use ratatui::layout::{Constraint, Direction, Layout, Rect};
use ratatui::style::{Color, Modifier, Style};
use ratatui::text::{Line, Span};
use ratatui::widgets::{Block, Borders, List, ListItem, ListState, Paragraph};
use reqwest::blocking::Client;
use serde::{Deserialize, Serialize};
use std::collections::{HashSet, VecDeque};
use std::fs;
use std::io::{BufReader, Stdout, Write};
use std::path::{Path, PathBuf};
use std::process::{Child, ChildStdin, Command, Stdio};
use std::sync::{
    Arc, Mutex,
    atomic::{AtomicBool, Ordering},
};
use std::thread::{self, JoinHandle};
use std::time::{Duration, SystemTime, UNIX_EPOCH};

#[derive(Clone, Debug)]
pub struct Channel {
    pub name: String,
    pub url: String,
}

#[derive(Clone, Debug)]
pub struct Theme {
    pub name: String,
    pub background: Color,
    pub foreground: Color,
    pub accent: Color,
    pub secondary: Color,
}

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum RecordingFormat {
    Wav,
    Mp3,
    Flac,
    Ogg,
}

impl RecordingFormat {
    fn next(self) -> Self {
        match self {
            Self::Wav => Self::Mp3,
            Self::Mp3 => Self::Flac,
            Self::Flac => Self::Ogg,
            Self::Ogg => Self::Wav,
        }
    }

    fn extension(self) -> &'static str {
        match self {
            Self::Wav => "wav",
            Self::Mp3 => "mp3",
            Self::Flac => "flac",
            Self::Ogg => "ogg",
        }
    }
}

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
enum VisualizerMode {
    Mirror,
    Hills,
    Split,
    Dots,
    Heart,
    Scope,
}

impl VisualizerMode {
    fn next(self) -> Self {
        match self {
            Self::Mirror => Self::Hills,
            Self::Hills => Self::Split,
            Self::Split => Self::Dots,
            Self::Dots => Self::Heart,
            Self::Heart => Self::Scope,
            Self::Scope => Self::Mirror,
        }
    }

    fn label(self) -> &'static str {
        match self {
            Self::Mirror => "mirror",
            Self::Hills => "hills",
            Self::Split => "split",
            Self::Dots => "orbit",
            Self::Heart => "heart",
            Self::Scope => "scope",
        }
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(default)]
struct PersistedConfig {
    theme_name: String,
    recording_format: RecordingFormat,
    visualizer_mode: VisualizerMode,
}

impl Default for PersistedConfig {
    fn default() -> Self {
        Self {
            theme_name: "tokyo_night".to_string(),
            recording_format: RecordingFormat::Mp3,
            visualizer_mode: VisualizerMode::Mirror,
        }
    }
}

pub struct AudioEngine {
    shared: Arc<Mutex<AudioShared>>,
    _stream: cpal::Stream,
    worker: Option<Worker>,
    music_dir: PathBuf,
}

struct Worker {
    stop: Arc<AtomicBool>,
    handle: JoinHandle<()>,
}

struct RecorderProcess {
    child: Child,
    stdin: ChildStdin,
    path: String,
}

struct AudioShared {
    buffer: VecDeque<f32>,
    start_index: u64,
    live_index: u64,
    play_index: u64,
    max_samples: usize,
    sample_rate: u32,
    channels: u16,
    volume: f32,
    paused: bool,
    bars: Vec<u64>,
    waveform: VecDeque<f32>,
    status: String,
    now_playing: String,
    recording_requested: bool,
    recording_active: bool,
    recording_path: String,
    recording_format: RecordingFormat,
}

pub struct App {
    channels: Vec<Channel>,
    list_state: ListState,
    engine: AudioEngine,
    themes: Vec<Theme>,
    theme_index: usize,
    config: PersistedConfig,
}

impl AudioShared {
    fn new(sample_rate: u32, channels: u16, recording_format: RecordingFormat) -> Self {
        let max_samples = sample_rate as usize * channels as usize * 30;
        Self {
            buffer: VecDeque::with_capacity(max_samples),
            start_index: 0,
            live_index: 0,
            play_index: 0,
            max_samples,
            sample_rate,
            channels,
            volume: 0.8,
            paused: false,
            bars: vec![0; 64],
            waveform: VecDeque::with_capacity(4096),
            status: "Idle".to_string(),
            now_playing: "Nothing playing".to_string(),
            recording_requested: false,
            recording_active: false,
            recording_path: String::new(),
            recording_format,
        }
    }

    fn append_samples(&mut self, samples: &[f32]) {
        let was_empty = self.live_index == self.start_index;
        for sample in samples {
            if self.buffer.len() == self.max_samples {
                self.buffer.pop_front();
                self.start_index += 1;
            }
            self.buffer.push_back(*sample);
            self.live_index += 1;
        }
        if was_empty {
            self.play_index = self.start_index;
        }
        if self.play_index < self.start_index {
            self.play_index = self.start_index;
        }
        self.update_bars(samples);
        self.update_waveform(samples);
    }

    fn update_bars(&mut self, samples: &[f32]) {
        if samples.is_empty() {
            return;
        }
        let mono = samples
            .chunks(self.channels as usize)
            .map(|frame| frame.iter().map(|v| v.abs()).sum::<f32>() / frame.len() as f32)
            .collect::<Vec<_>>();
        let band_len = (mono.len() / self.bars.len().max(1)).max(1);
        for (index, bar) in self.bars.iter_mut().enumerate() {
            let start = index * band_len;
            let end = ((index + 1) * band_len).min(mono.len());
            let value = if start >= end {
                0.0
            } else {
                mono[start..end].iter().sum::<f32>() / (end - start) as f32
            };
            let target = (value * 180.0).clamp(0.0, 100.0) as f64;
            let current = *bar as f64;
            *bar = (current * 0.72 + target * 0.28).round() as u64;
        }
    }

    fn update_waveform(&mut self, samples: &[f32]) {
        if samples.is_empty() {
            return;
        }
        let mono = samples
            .chunks(self.channels as usize)
            .map(|frame| frame.iter().copied().sum::<f32>() / frame.len() as f32)
            .collect::<Vec<_>>();
        let stride = (mono.len() / 128).max(1);
        for chunk in mono.chunks(stride) {
            let sample = chunk.iter().copied().sum::<f32>() / chunk.len() as f32;
            let previous = self.waveform.back().copied().unwrap_or(0.0);
            let smoothed = previous * 0.54 + sample * 0.46;
            if self.waveform.len() == 4096 {
                self.waveform.pop_front();
            }
            self.waveform.push_back(smoothed.clamp(-1.0, 1.0));
        }
    }

    fn rewind_seconds(&mut self, seconds: u64) {
        let delta = seconds * self.sample_rate as u64 * self.channels as u64;
        self.play_index = self.live_index.saturating_sub(delta).max(self.start_index);
        self.paused = false;
    }

    fn go_live(&mut self) {
        self.play_index = self.live_index;
        self.paused = false;
    }

    fn buffered_seconds(&self) -> u64 {
        if self.sample_rate == 0 || self.channels == 0 {
            return 0;
        }
        (self.live_index.saturating_sub(self.start_index))
            / self.sample_rate as u64
            / self.channels as u64
    }

    fn delay_seconds(&self) -> u64 {
        if self.sample_rate == 0 || self.channels == 0 {
            return 0;
        }
        (self.live_index.saturating_sub(self.play_index))
            / self.sample_rate as u64
            / self.channels as u64
    }
}

impl AudioEngine {
    pub fn new(music_dir: PathBuf, recording_format: RecordingFormat) -> Result<Self> {
        let host = cpal::default_host();
        let device = host
            .default_output_device()
            .ok_or_else(|| anyhow!("no default output device"))?;
        let supported = device.default_output_config()?;
        let sample_rate = supported.sample_rate().0;
        let channels = supported.channels();
        let shared = Arc::new(Mutex::new(AudioShared::new(
            sample_rate,
            channels,
            recording_format,
        )));
        let stream = match supported.sample_format() {
            cpal::SampleFormat::F32 => {
                build_stream::<f32>(&device, &supported.into(), shared.clone())?
            }
            cpal::SampleFormat::I16 => {
                build_stream::<i16>(&device, &supported.into(), shared.clone())?
            }
            cpal::SampleFormat::U16 => {
                build_stream::<u16>(&device, &supported.into(), shared.clone())?
            }
            other => return Err(anyhow!("unsupported sample format: {other:?}")),
        };
        stream.play()?;
        Ok(Self {
            shared,
            _stream: stream,
            worker: None,
            music_dir,
        })
    }

    pub fn play(&mut self, channel: Channel) {
        self.stop_worker();
        if let Ok(mut shared) = self.shared.lock() {
            shared.buffer.clear();
            shared.start_index = 0;
            shared.live_index = 0;
            shared.play_index = 0;
            shared.paused = false;
            shared.status = format!("Connecting to {}", channel.name);
            shared.now_playing = channel.name.clone();
            shared.recording_active = false;
            shared.recording_path.clear();
        }
        let shared = self.shared.clone();
        let stop = Arc::new(AtomicBool::new(false));
        let stop_worker = stop.clone();
        let music_dir = self.music_dir.clone();
        let handle = thread::spawn(move || {
            run_stream_worker(channel, shared, stop_worker, music_dir);
        });
        self.worker = Some(Worker { stop, handle });
    }

    pub fn toggle_pause(&self) {
        if let Ok(mut shared) = self.shared.lock() {
            shared.paused = !shared.paused;
            shared.status = if shared.paused {
                "Paused".to_string()
            } else {
                "Playing".to_string()
            };
        }
    }

    pub fn set_volume_delta(&self, delta: f32) {
        if let Ok(mut shared) = self.shared.lock() {
            shared.volume = (shared.volume + delta).clamp(0.0, 2.0);
        }
    }

    pub fn rewind_seconds(&self, seconds: u64) {
        if let Ok(mut shared) = self.shared.lock() {
            shared.rewind_seconds(seconds);
            shared.status = format!("Rewound {seconds} second(s)");
        }
    }

    pub fn go_live(&self) {
        if let Ok(mut shared) = self.shared.lock() {
            shared.go_live();
            shared.status = "Live".to_string();
        }
    }

    pub fn toggle_recording(&self) {
        if let Ok(mut shared) = self.shared.lock() {
            shared.recording_requested = !shared.recording_requested;
            if !shared.recording_requested {
                shared.recording_active = false;
                shared.recording_path.clear();
            }
        }
    }

    pub fn cycle_recording_format(&self) -> RecordingFormat {
        let mut format = RecordingFormat::Wav;
        if let Ok(mut shared) = self.shared.lock() {
            shared.recording_format = shared.recording_format.next();
            format = shared.recording_format;
            shared.status = format!("Recording format: {}", format.extension());
        }
        format
    }

    pub fn snapshot(&self) -> AudioSnapshot {
        let shared = self.shared.lock().expect("audio shared");
        AudioSnapshot {
            volume: shared.volume,
            paused: shared.paused,
            bars: shared.bars.clone(),
            waveform: shared.waveform.iter().copied().collect(),
            status: shared.status.clone(),
            now_playing: shared.now_playing.clone(),
            buffered_seconds: shared.buffered_seconds(),
            delay_seconds: shared.delay_seconds(),
            recording_requested: shared.recording_requested,
            recording_active: shared.recording_active,
            recording_path: shared.recording_path.clone(),
            recording_format: shared.recording_format,
        }
    }

    fn stop_worker(&mut self) {
        if let Some(worker) = self.worker.take() {
            worker.stop.store(true, Ordering::SeqCst);
            let _ = worker.handle.join();
        }
    }
}

impl Drop for AudioEngine {
    fn drop(&mut self) {
        self.stop_worker();
    }
}

pub struct AudioSnapshot {
    pub volume: f32,
    pub paused: bool,
    pub bars: Vec<u64>,
    pub waveform: Vec<f32>,
    pub status: String,
    pub now_playing: String,
    pub buffered_seconds: u64,
    pub delay_seconds: u64,
    pub recording_requested: bool,
    pub recording_active: bool,
    pub recording_path: String,
    pub recording_format: RecordingFormat,
}

pub fn run(music_dir: PathBuf) -> Result<()> {
    let channels = fetch_channels()?;
    let themes = load_alacritty_themes()?;
    let config = load_persisted_config();
    let theme_index = themes
        .iter()
        .position(|theme| theme.name.eq_ignore_ascii_case(&config.theme_name))
        .unwrap_or(0);
    let mut terminal = setup_terminal()?;
    let engine = AudioEngine::new(music_dir, config.recording_format)?;
    let mut app = App::new(channels, engine, themes, theme_index, config);
    app.run(&mut terminal)?;
    restore_terminal(terminal)?;
    Ok(())
}

impl App {
    fn new(
        channels: Vec<Channel>,
        engine: AudioEngine,
        themes: Vec<Theme>,
        theme_index: usize,
        config: PersistedConfig,
    ) -> Self {
        let mut list_state = ListState::default();
        list_state.select(Some(0));
        Self {
            channels,
            list_state,
            engine,
            themes,
            theme_index,
            config,
        }
    }

    fn run(&mut self, terminal: &mut Terminal<CrosstermBackend<Stdout>>) -> Result<()> {
        loop {
            let snapshot = self.engine.snapshot();
            let theme = self.themes[self.theme_index].clone();
            terminal.draw(|frame| self.draw(frame, &snapshot, &theme))?;
            if event::poll(Duration::from_millis(80))? {
                if let Event::Key(key) = event::read()? {
                    if key.kind != KeyEventKind::Press {
                        continue;
                    }
                    match key.code {
                        KeyCode::Char('q') => break,
                        KeyCode::Down | KeyCode::Char('j') => self.next_channel(),
                        KeyCode::Up | KeyCode::Char('k') => self.prev_channel(),
                        KeyCode::Enter => {
                            if let Some(channel) = self.selected_channel() {
                                self.engine.play(channel);
                            }
                        }
                        KeyCode::Char(' ') => self.engine.toggle_pause(),
                        KeyCode::Char('+') | KeyCode::Char('=') => {
                            self.engine.set_volume_delta(0.05)
                        }
                        KeyCode::Char('-') => self.engine.set_volume_delta(-0.05),
                        KeyCode::Char('1') => self.engine.rewind_seconds(10),
                        KeyCode::Char('2') => self.engine.rewind_seconds(20),
                        KeyCode::Char('3') => self.engine.rewind_seconds(30),
                        KeyCode::Char('l') => self.engine.go_live(),
                        KeyCode::Char('t') => self.next_theme(),
                        KeyCode::Char('T') => self.prev_theme(),
                        KeyCode::Char('v') => self.next_visualizer(),
                        KeyCode::Char('m') => self.next_recording_format(),
                        KeyCode::Char('r') => self.engine.toggle_recording(),
                        _ => {}
                    }
                }
            }
        }
        Ok(())
    }

    fn draw(&self, frame: &mut ratatui::Frame<'_>, snapshot: &AudioSnapshot, theme: &Theme) {
        let total_width = frame.area().width;
        let sidebar = total_width.clamp(24, 34);
        let chunks = Layout::default()
            .direction(Direction::Horizontal)
            .constraints([Constraint::Length(sidebar), Constraint::Min(72)])
            .split(frame.area());
        let right = Layout::default()
            .direction(Direction::Vertical)
            .constraints([
                Constraint::Length(4),
                Constraint::Min(24),
                Constraint::Length(7),
            ])
            .split(chunks[1]);

        self.draw_channels(frame, chunks[0], theme);
        self.draw_now_playing(frame, right[0], snapshot, theme);
        self.draw_visualizer(frame, right[1], snapshot, theme);
        self.draw_help(frame, right[2], snapshot, theme);
    }

    fn draw_channels(&self, frame: &mut ratatui::Frame<'_>, area: Rect, theme: &Theme) {
        let items = self
            .channels
            .iter()
            .map(|channel| {
                ListItem::new(Line::from(vec![
                    Span::styled("󰓃 ", Style::default().fg(theme.secondary)),
                    Span::raw(channel.name.clone()),
                ]))
            })
            .collect::<Vec<_>>();
        let list = List::new(items)
            .block(
                Block::default()
                    .title("Sveriges Radio")
                    .borders(Borders::ALL)
                    .border_style(Style::default().fg(theme.accent))
                    .style(Style::default().bg(Color::Reset).fg(theme.foreground)),
            )
            .highlight_style(
                Style::default()
                    .fg(theme.background)
                    .bg(theme.accent)
                    .add_modifier(Modifier::BOLD),
            )
            .highlight_symbol("▶ ");
        let mut state = self.list_state.clone();
        frame.render_stateful_widget(list, area, &mut state);
    }

    fn draw_now_playing(
        &self,
        frame: &mut ratatui::Frame<'_>,
        area: Rect,
        snapshot: &AudioSnapshot,
        theme: &Theme,
    ) {
        let recording = if snapshot.recording_requested {
            if snapshot.recording_active {
                snapshot.recording_path.clone()
            } else {
                "arming".to_string()
            }
        } else {
            "off".to_string()
        };
        let lines = vec![
            Line::from(vec![
                Span::styled("󰐊 ", Style::default().fg(theme.secondary)),
                Span::styled(
                    snapshot.now_playing.clone(),
                    Style::default().add_modifier(Modifier::BOLD),
                ),
                Span::raw("  "),
                Span::styled("󰞌 ", Style::default().fg(theme.accent)),
                Span::raw(if snapshot.paused {
                    "Paused".to_string()
                } else {
                    snapshot.status.clone()
                }),
                Span::raw("  "),
                Span::styled("󰕾 ", Style::default().fg(theme.secondary)),
                Span::raw(format!("{:>3.0}%", snapshot.volume * 100.0)),
            ]),
            Line::from(vec![
                Span::styled("󰸌 ", Style::default().fg(theme.accent)),
                Span::raw(self.themes[self.theme_index].name.clone()),
                Span::raw("  "),
                Span::styled("󰗊 ", Style::default().fg(theme.foreground)),
                Span::raw(snapshot.recording_format.extension()),
                Span::raw("  "),
                Span::styled("󰻃 ", Style::default().fg(theme.secondary)),
                Span::raw(recording),
                Span::raw("  "),
                Span::styled("󰕍 ", Style::default().fg(theme.accent)),
                Span::raw(self.config.visualizer_mode.label().to_string()),
            ]),
        ];
        let widget = Paragraph::new(lines).block(
            Block::default()
                .title("󰎈 Now Playing")
                .borders(Borders::ALL)
                .border_style(Style::default().fg(theme.accent))
                .style(Style::default().bg(Color::Reset).fg(theme.foreground)),
        );
        frame.render_widget(widget, area);
    }

    fn draw_visualizer(
        &self,
        frame: &mut ratatui::Frame<'_>,
        area: Rect,
        snapshot: &AudioSnapshot,
        theme: &Theme,
    ) {
        let inner_height = area.height.saturating_sub(2);
        let inner_width = area.width.saturating_sub(2);
        let columns = resample_bars(&snapshot.bars, inner_width as usize);
        let lines = render_visualizer_lines(
            &columns,
            &snapshot.waveform,
            inner_width as usize,
            inner_height as usize,
            theme,
            self.config.visualizer_mode,
        );
        let widget = Paragraph::new(lines).block(
            Block::default()
                .title("󰕍")
                .borders(Borders::ALL)
                .border_style(Style::default().fg(theme.secondary))
                .style(Style::default().bg(Color::Reset).fg(theme.foreground)),
        );
        frame.render_widget(widget, area);
    }

    fn draw_help(
        &self,
        frame: &mut ratatui::Frame<'_>,
        area: Rect,
        snapshot: &AudioSnapshot,
        theme: &Theme,
    ) {
        let lines = vec![
            Line::from("󰒭 ↑/↓ or j/k select channel"),
            Line::from("󰐊 Enter play  󰏤 Space pause  󰕾 +/- volume"),
            Line::from("󰁝 1/2/3 rewind 10/20/30s  󰑓 l live"),
            Line::from("󰸌 t/T theme  󰕍 v cycle visualizer"),
            Line::from("󰗊 m format  󰻃 r record  󰗼 q quit"),
            Line::from(format!(
                "󰆍 live-{}s stored {}s  󰕍 {}",
                snapshot.delay_seconds,
                snapshot.buffered_seconds,
                self.config.visualizer_mode.label()
            )),
            Line::from(format!(
                "󰔚 Mode: {}",
                if snapshot.delay_seconds == 0 {
                    "live"
                } else {
                    "timeshift"
                }
            )),
        ];
        let widget = Paragraph::new(lines).block(
            Block::default()
                .title("󱁤 Controls")
                .borders(Borders::ALL)
                .border_style(Style::default().fg(theme.secondary))
                .style(Style::default().bg(Color::Reset).fg(theme.foreground)),
        );
        frame.render_widget(widget, area);
    }

    fn next_channel(&mut self) {
        let next = match self.list_state.selected() {
            Some(index) if index + 1 < self.channels.len() => index + 1,
            _ => 0,
        };
        self.list_state.select(Some(next));
    }

    fn prev_channel(&mut self) {
        let prev = match self.list_state.selected() {
            Some(index) if index > 0 => index - 1,
            _ => self.channels.len().saturating_sub(1),
        };
        self.list_state.select(Some(prev));
    }

    fn next_theme(&mut self) {
        self.theme_index = (self.theme_index + 1) % self.themes.len();
        self.persist_theme();
    }

    fn prev_theme(&mut self) {
        self.theme_index = if self.theme_index == 0 {
            self.themes.len().saturating_sub(1)
        } else {
            self.theme_index - 1
        };
        self.persist_theme();
    }

    fn next_recording_format(&mut self) {
        let format = self.engine.cycle_recording_format();
        self.config.recording_format = format;
        let _ = save_persisted_config(&self.config);
    }

    fn next_visualizer(&mut self) {
        self.config.visualizer_mode = self.config.visualizer_mode.next();
        let _ = save_persisted_config(&self.config);
    }

    fn persist_theme(&mut self) {
        self.config.theme_name = self.themes[self.theme_index].name.clone();
        let _ = save_persisted_config(&self.config);
    }

    fn selected_channel(&self) -> Option<Channel> {
        let index = self.list_state.selected()?;
        self.channels.get(index).cloned()
    }
}

fn run_stream_worker(
    channel: Channel,
    shared: Arc<Mutex<AudioShared>>,
    stop: Arc<AtomicBool>,
    music_dir: PathBuf,
) {
    let client = Client::builder()
        .user_agent("srtui/0.1")
        .build()
        .expect("client");
    let response = match client.get(&channel.url).send() {
        Ok(response) => response,
        Err(err) => {
            if let Ok(mut state) = shared.lock() {
                state.status = format!("Connection failed: {err}");
            }
            return;
        }
    };
    if let Ok(mut state) = shared.lock() {
        state.status = "Streaming".to_string();
    }
    let mut decoder = minimp3::Decoder::new(BufReader::new(response));
    let mut recorder: Option<RecorderProcess> = None;
    loop {
        if stop.load(Ordering::SeqCst) {
            break;
        }
        match decoder.next_frame() {
            Ok(frame) => {
                let (dst_rate, dst_channels, want_recording, current_name, format) = {
                    let state = shared.lock().expect("shared");
                    (
                        state.sample_rate,
                        state.channels,
                        state.recording_requested,
                        state.now_playing.clone(),
                        state.recording_format,
                    )
                };
                let samples = resample_interleaved(
                    &frame.data,
                    frame.sample_rate as u32,
                    frame.channels as u16,
                    dst_rate,
                    dst_channels,
                );
                if let Ok(mut state) = shared.lock() {
                    state.append_samples(&samples);
                    state.status = "Streaming".to_string();
                    if want_recording && recorder.is_none() {
                        match start_recorder(&music_dir, &current_name, dst_rate, dst_channels, format)
                        {
                            Ok(created) => {
                                state.recording_active = true;
                                state.recording_path = created.path.clone();
                                recorder = Some(created);
                            }
                            Err(err) => {
                                state.status = format!("Recording failed: {err}");
                                state.recording_requested = false;
                            }
                        }
                    }
                    if !want_recording && recorder.is_some() {
                        if let Some(open) = recorder.take() {
                            let _ = stop_recorder(open);
                        }
                        state.recording_active = false;
                        state.recording_path.clear();
                    }
                }
                if let Some(open) = recorder.as_mut() {
                    let mut bytes = Vec::with_capacity(samples.len() * 2);
                    for sample in &samples {
                        let scaled = (sample.clamp(-1.0, 1.0) * i16::MAX as f32) as i16;
                        bytes.extend_from_slice(&scaled.to_le_bytes());
                    }
                    if open.stdin.write_all(&bytes).is_err() {
                        break;
                    }
                }
            }
            Err(minimp3::Error::Eof) => break,
            Err(_) => continue,
        }
    }
    if let Some(open) = recorder {
        let _ = stop_recorder(open);
    }
}

fn start_recorder(
    music_dir: &Path,
    name: &str,
    sample_rate: u32,
    channels: u16,
    format: RecordingFormat,
) -> Result<RecorderProcess> {
    let path = recording_path(music_dir, name, format);
    let mut command = Command::new("ffmpeg");
    command
        .arg("-hide_banner")
        .arg("-loglevel")
        .arg("error")
        .arg("-f")
        .arg("s16le")
        .arg("-ar")
        .arg(sample_rate.to_string())
        .arg("-ac")
        .arg(channels.to_string())
        .arg("-i")
        .arg("pipe:0")
        .arg("-y");
    match format {
        RecordingFormat::Wav => {}
        RecordingFormat::Mp3 => {
            command.arg("-c:a").arg("libmp3lame").arg("-b:a").arg("192k");
        }
        RecordingFormat::Flac => {
            command.arg("-c:a").arg("flac");
        }
        RecordingFormat::Ogg => {
            command.arg("-c:a").arg("libvorbis").arg("-q:a").arg("5");
        }
    }
    command.arg(&path);
    let mut child = command.stdin(Stdio::piped()).stdout(Stdio::null()).spawn()?;
    let stdin = child
        .stdin
        .take()
        .ok_or_else(|| anyhow!("failed to open ffmpeg stdin"))?;
    Ok(RecorderProcess {
        child,
        stdin,
        path: path.to_string_lossy().to_string(),
    })
}

fn stop_recorder(mut recorder: RecorderProcess) -> Result<()> {
    drop(recorder.stdin);
    let status = recorder.child.wait()?;
    if !status.success() {
        return Err(anyhow!("ffmpeg exited with {status}"));
    }
    Ok(())
}

fn build_stream<T>(
    device: &cpal::Device,
    config: &cpal::StreamConfig,
    shared: Arc<Mutex<AudioShared>>,
) -> Result<cpal::Stream>
where
    T: cpal::Sample + cpal::SizedSample + cpal::FromSample<f32>,
{
    let channels = config.channels as usize;
    let stream = device.build_output_stream(
        config,
        move |data: &mut [T], _| {
            let mut state = match shared.lock() {
                Ok(state) => state,
                Err(_) => return,
            };
            for frame in data.chunks_mut(channels) {
                for sample in frame.iter_mut() {
                    let value = if state.paused || state.play_index >= state.live_index {
                        0.0
                    } else {
                        let offset = state.play_index.saturating_sub(state.start_index) as usize;
                        let sample = state.buffer.get(offset).copied().unwrap_or(0.0);
                        state.play_index += 1;
                        sample * state.volume
                    };
                    *sample = T::from_sample(value);
                }
            }
        },
        move |err| {
            eprintln!("{err}");
        },
        None,
    )?;
    Ok(stream)
}

fn resample_interleaved(
    input: &[i16],
    src_rate: u32,
    src_channels: u16,
    dst_rate: u32,
    dst_channels: u16,
) -> Vec<f32> {
    if input.is_empty() {
        return Vec::new();
    }
    let src_channels_usize = src_channels as usize;
    let dst_channels_usize = dst_channels as usize;
    let src_frames = input.len() / src_channels_usize;
    if src_frames == 0 {
        return Vec::new();
    }
    let dst_frames = ((src_frames as f64 * dst_rate as f64) / src_rate as f64).max(1.0) as usize;
    let mut output = Vec::with_capacity(dst_frames * dst_channels_usize);
    for frame_index in 0..dst_frames {
        let src_pos = frame_index as f64 * src_rate as f64 / dst_rate as f64;
        let base = src_pos.floor() as usize;
        let next = (base + 1).min(src_frames.saturating_sub(1));
        let frac = (src_pos - base as f64) as f32;
        for channel_index in 0..dst_channels_usize {
            let src_channel = channel_index.min(src_channels_usize.saturating_sub(1));
            let a = input[base * src_channels_usize + src_channel] as f32 / i16::MAX as f32;
            let b = input[next * src_channels_usize + src_channel] as f32 / i16::MAX as f32;
            output.push(a + (b - a) * frac);
        }
    }
    output
}

fn recording_path(music_dir: &Path, name: &str, format: RecordingFormat) -> PathBuf {
    let _ = fs::create_dir_all(music_dir);
    let stamp = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs();
    let safe = name
        .chars()
        .map(|ch| if ch.is_ascii_alphanumeric() { ch } else { '_' })
        .collect::<String>();
    music_dir.join(format!("{safe}-{stamp}.{}", format.extension()))
}

fn resample_bars(source: &[u64], width: usize) -> Vec<u64> {
    if width == 0 || source.is_empty() {
        return Vec::new();
    }
    if source.len() == 1 {
        return vec![source[0]; width];
    }
    let mut out = Vec::with_capacity(width);
    let max_index = source.len() - 1;
    for x in 0..width {
        let pos = x as f64 * max_index as f64 / width.saturating_sub(1).max(1) as f64;
        let left = pos.floor() as usize;
        let right = (left + 1).min(max_index);
        let frac = pos - left as f64;
        let a = source[left] as f64;
        let b = source[right] as f64;
        out.push((a + (b - a) * frac).round() as u64);
    }
    out
}

fn render_visualizer_lines(
    columns: &[u64],
    waveform: &[f32],
    width: usize,
    height: usize,
    theme: &Theme,
    mode: VisualizerMode,
) -> Vec<Line<'static>> {
    if width == 0 || height == 0 || columns.is_empty() {
        return vec![Line::from("")];
    }
    match mode {
        VisualizerMode::Mirror => render_mirror_lines(columns, width, height, theme),
        VisualizerMode::Hills => render_hills_lines(columns, width, height, theme),
        VisualizerMode::Split => render_split_lines(columns, width, height, theme),
        VisualizerMode::Dots => render_dot_lines(columns, width, height, theme),
        VisualizerMode::Heart => render_heart_lines(columns, width, height, theme),
        VisualizerMode::Scope => render_scope_waveform(waveform, width, height, theme),
    }
}

fn render_mirror_lines(
    columns: &[u64],
    width: usize,
    height: usize,
    theme: &Theme,
) -> Vec<Line<'static>> {
    let sampled = amplify_columns(&soften_columns(columns, 0.78), 1.42, 9.0);
    let half = width.max(8) / 2;
    let curve = build_visual_curve(&resample_bars(&sampled, half.max(8)), half.max(8), 0.34, 0.12);
    let mut traces = Vec::new();
    traces.push(curve.iter().map(|v| (-v * 0.92).clamp(-1.0, 1.0)).collect());
    traces.push(curve.iter().map(|v| (-v * 0.56).clamp(-1.0, 1.0)).collect());
    traces.push(curve.iter().map(|v| (v * 0.56).clamp(-1.0, 1.0)).collect());
    traces.push(curve.iter().map(|v| (v * 0.92).clamp(-1.0, 1.0)).collect());
    render_wave_stack(&traces, width, height, theme, WaveRenderMode::Mirror)
}

fn render_hills_lines(
    columns: &[u64],
    width: usize,
    height: usize,
    theme: &Theme,
) -> Vec<Line<'static>> {
    let sampled = amplify_columns(&soften_columns(columns, 0.82), 1.38, 8.0);
    let base = build_visual_curve(&resample_bars(&sampled, width.max(12)), width.max(12), 0.26, 0.08);
    let traces = vec![
        base.iter().map(|v| (v * 0.28 + 0.62).clamp(-1.0, 1.0)).collect(),
        base.iter().map(|v| (v * 0.42 + 0.24).clamp(-1.0, 1.0)).collect(),
        base.iter().map(|v| (v * 0.54 - 0.14).clamp(-1.0, 1.0)).collect(),
        base.iter().map(|v| (v * 0.68 - 0.56).clamp(-1.0, 1.0)).collect(),
    ];
    render_wave_stack(&traces, width, height, theme, WaveRenderMode::Hills)
}

fn render_split_lines(
    columns: &[u64],
    width: usize,
    height: usize,
    theme: &Theme,
) -> Vec<Line<'static>> {
    let sampled = amplify_columns(&soften_columns(columns, 0.8), 1.4, 8.0);
    let left_curve = build_visual_curve(
        &resample_bars(&sampled, width.max(10) / 2),
        width.max(10) / 2,
        0.3,
        0.11,
    );
    let right_curve = left_curve.iter().rev().copied().collect::<Vec<_>>();
    let traces = vec![
        left_curve.iter().map(|v| (v * 0.88 - 0.48).clamp(-1.0, 1.0)).collect(),
        left_curve.iter().map(|v| (v * 0.54 + 0.22).clamp(-1.0, 1.0)).collect(),
        right_curve.iter().map(|v| (v * 0.54 - 0.22).clamp(-1.0, 1.0)).collect(),
        right_curve.iter().map(|v| (v * 0.88 + 0.48).clamp(-1.0, 1.0)).collect(),
    ];
    render_wave_stack(&traces, width, height, theme, WaveRenderMode::Split)
}

fn render_dot_lines(
    columns: &[u64],
    width: usize,
    height: usize,
    theme: &Theme,
) -> Vec<Line<'static>> {
    let sampled = amplify_columns(&soften_columns(columns, 0.84), 1.48, 10.0);
    let curve = build_visual_curve(&resample_bars(&sampled, width.max(16)), width.max(16), 0.28, 0.12);
    render_orbit_field(&curve, width, height, theme)
}

fn render_heart_lines(
    columns: &[u64],
    width: usize,
    height: usize,
    theme: &Theme,
) -> Vec<Line<'static>> {
    let sampled = amplify_columns(&soften_columns(columns, 0.8), 1.55, 12.0);
    let curve = build_visual_curve(&resample_bars(&sampled, 144), 144, 0.26, 0.09);
    render_heart_field(&curve, width, height, theme)
}

fn render_scope_waveform(
    waveform: &[f32],
    width: usize,
    height: usize,
    theme: &Theme,
) -> Vec<Line<'static>> {
    if width == 0 || height == 0 {
        return vec![Line::from("")];
    }
    let tail_count = if width > 120 { 6usize } else { 5usize };
    let segment_len = width.max(24) * 14;
    let mut traces = Vec::with_capacity(tail_count);
    for age in (0..tail_count).rev() {
        let offset = age * width.max(18) * 3;
        let end = waveform.len().saturating_sub(offset);
        let start = end.saturating_sub(segment_len);
        let slice = &waveform[start.min(end)..end];
        if slice.is_empty() {
            continue;
        }
        let sampled = resample_waveform(slice, width.max(24) * 4);
        let filtered = smooth_waveform(&sampled, 0.80 + age as f32 * 0.03);
        let centered = remove_dc_bias(&filtered);
        let shaped = sculpt_scope_wave(&smooth_curve(&centered));
        traces.push(shaped);
    }
    render_scope_braille(&traces, width, height, theme)
}

fn render_scope_braille(
    traces: &[Vec<f32>],
    width: usize,
    height: usize,
    theme: &Theme,
) -> Vec<Line<'static>> {
    let pixel_width = width.max(1) * 4;
    let pixel_height = height.max(1) * 4;
    let center = pixel_height as f32 / 2.0;
    let amplitude = center.max(1.0) - 3.0;
    let mut masks = vec![vec![0u8; width]; height];
    let mut styles = vec![vec![Style::default().bg(Color::Reset); width]; height];
    let mut ranks = vec![vec![0u8; width]; height];
    for (trace_index, trace) in traces.iter().enumerate() {
        let points = resample_waveform(trace, pixel_width)
            .iter()
            .map(|sample| (center - sample.clamp(-1.0, 1.0) * amplitude).round() as isize)
            .collect::<Vec<_>>();
        for x in 1..points.len().min(pixel_width) {
            let prev_y = points[x - 1].clamp(0, pixel_height.saturating_sub(1) as isize);
            let curr_y = points[x].clamp(0, pixel_height.saturating_sub(1) as isize);
            let is_tip = x + 1 == points.len().min(pixel_width);
            for (px, py) in raster_line((x - 1) as isize, prev_y, x as isize, curr_y) {
                set_braille_pixel(
                    &mut masks,
                    &mut styles,
                    &mut ranks,
                    px as usize,
                    py as usize,
                    scope_trace_style(trace_index, py as usize / 4, height, theme, traces.len()),
                    scope_rank(trace_index, is_tip),
                );
            }
        }
    }
    let mut lines = Vec::with_capacity(height);
    for row in 0..height {
        let spans = (0..width)
            .map(|col| Span::styled(braille_char(masks[row][col]).to_string(), styles[row][col]))
            .collect::<Vec<_>>();
        lines.push(Line::from(spans));
    }
    lines
}

fn render_wave_stack(
    traces: &[Vec<f32>],
    width: usize,
    height: usize,
    theme: &Theme,
    mode: WaveRenderMode,
) -> Vec<Line<'static>> {
    let pixel_width = width.max(1) * 4;
    let pixel_height = height.max(1) * 4;
    let center = pixel_height as f32 / 2.0;
    let amplitude = center.max(1.0) - 3.0;
    let mut masks = vec![vec![0u8; width]; height];
    let mut styles = vec![vec![Style::default().bg(Color::Reset); width]; height];
    let mut ranks = vec![vec![0u8; width]; height];
    for (trace_index, trace) in traces.iter().enumerate() {
        let points = resample_waveform(trace, pixel_width)
            .iter()
            .map(|sample| (center - sample.clamp(-1.0, 1.0) * amplitude).round() as isize)
            .collect::<Vec<_>>();
        for x in 1..points.len().min(pixel_width) {
            let prev_y = points[x - 1].clamp(0, pixel_height.saturating_sub(1) as isize);
            let curr_y = points[x].clamp(0, pixel_height.saturating_sub(1) as isize);
            let is_tip = x + 1 == points.len().min(pixel_width);
            for (px, py) in raster_line((x - 1) as isize, prev_y, x as isize, curr_y) {
                let style = wave_trace_style(
                    trace_index,
                    py as usize / 4,
                    height,
                    theme,
                    traces.len(),
                    mode,
                );
                set_braille_pixel(
                    &mut masks,
                    &mut styles,
                    &mut ranks,
                    px as usize,
                    py as usize,
                    style,
                    scope_rank(trace_index, is_tip),
                );
            }
        }
    }
    let mut lines = Vec::with_capacity(height);
    for row in 0..height {
        let spans = (0..width)
            .map(|col| Span::styled(braille_char(masks[row][col]).to_string(), styles[row][col]))
            .collect::<Vec<_>>();
        lines.push(Line::from(spans));
    }
    lines
}

fn render_orbit_field(
    curve: &[f32],
    width: usize,
    height: usize,
    theme: &Theme,
) -> Vec<Line<'static>> {
    let pixel_width = width.max(1) * 4;
    let pixel_height = height.max(1) * 4;
    let center_x = pixel_width as f32 / 2.0;
    let center_y = pixel_height as f32 / 2.0;
    let max_radius = pixel_height.min(pixel_width) as f32 * 0.27;
    let base_radius = max_radius * 0.58;
    let mut masks = vec![vec![0u8; width]; height];
    let mut styles = vec![vec![Style::default().bg(Color::Reset); width]; height];
    let mut ranks = vec![vec![0u8; width]; height];
    let rings = [0.68f32, 0.92, 1.16];
    let energies = curve
        .iter()
        .map(|sample| (((sample.abs() * 0.5) + 0.5) * 100.0).clamp(0.0, 100.0) as u64)
        .collect::<Vec<_>>();
    for (ring_index, ring_scale) in rings.iter().enumerate() {
        let mut points = Vec::with_capacity(energies.len());
        for (index, energy) in energies.iter().enumerate() {
            let angle = index as f32 / energies.len().max(1) as f32 * std::f32::consts::TAU;
            let pulse = (*energy as f32 / 100.0).clamp(0.0, 1.0);
            let radius = base_radius * ring_scale
                + pulse * (max_radius * 0.22)
                + (curve[index % curve.len()] * max_radius * 0.12)
                + (angle * 2.0 + ring_index as f32 * 0.9).sin() * (5.0 + ring_index as f32 * 2.5);
            let x = (center_x + radius * angle.cos()).round() as isize;
            let y = (center_y + radius * angle.sin()).round() as isize;
            points.push((x, y));
        }
        for index in 1..points.len() {
            let (x0, y0) = points[index - 1];
            let (x1, y1) = points[index];
            let rank = ((ring_index + 1) * 3) as u8;
            let style = wave_trace_style(
                ring_index,
                (y1.max(0) as usize / 4).min(height.saturating_sub(1)),
                height,
                theme,
                rings.len(),
                WaveRenderMode::Dots,
            );
            for (px, py) in raster_line(x0, y0, x1, y1) {
                if px < 0 || py < 0 {
                    continue;
                }
                set_braille_pixel(
                    &mut masks,
                    &mut styles,
                    &mut ranks,
                    px as usize,
                    py as usize,
                    style,
                    rank,
                );
            }
        }
    }
    let mut lines = Vec::with_capacity(height);
    for row in 0..height {
        let spans = (0..width)
            .map(|col| Span::styled(braille_char(masks[row][col]).to_string(), styles[row][col]))
            .collect::<Vec<_>>();
        lines.push(Line::from(spans));
    }
    lines
}

fn render_heart_field(
    curve: &[f32],
    width: usize,
    height: usize,
    theme: &Theme,
) -> Vec<Line<'static>> {
    let pixel_width = width.max(1) * 4;
    let pixel_height = height.max(1) * 4;
    let center_x = pixel_width as f32 / 2.0;
    let center_y = pixel_height as f32 * 0.52;
    let safe_scale_x = pixel_width as f32 / 36.0;
    let safe_scale_y = pixel_height as f32 / 34.0;
    let base_scale = safe_scale_x.min(safe_scale_y) * 0.92;
    let beat = (curve.iter().map(|v| v.abs()).sum::<f32>() / curve.len().max(1) as f32).clamp(0.0, 1.0);
    let beat_scale = 0.88 + beat * 0.38;
    let mut masks = vec![vec![0u8; width]; height];
    let mut styles = vec![vec![Style::default().bg(Color::Reset); width]; height];
    let mut ranks = vec![vec![0u8; width]; height];
    let layers = [0.82f32, 0.94, 1.06];
    let detail = resample_waveform(curve, 180);
    for (layer_index, layer_scale) in layers.iter().enumerate() {
        let mut points = Vec::with_capacity(detail.len() + 1);
        for (index, value) in detail.iter().enumerate() {
            let t = index as f32 / detail.len().max(1) as f32 * std::f32::consts::TAU;
            let pulse = value.abs().clamp(0.0, 1.0);
            let scale = base_scale * beat_scale * layer_scale * (1.0 + pulse * 0.14);
            let x = 16.0 * t.sin().powi(3);
            let y = 13.0 * t.cos() - 5.0 * (2.0 * t).cos() - 2.0 * (3.0 * t).cos() - (4.0 * t).cos();
            let px = (center_x + x * scale).round() as isize;
            let py = (center_y - y * scale * 0.94).round() as isize;
            points.push((px, py));
        }
        if let Some(first) = points.first().copied() {
            points.push(first);
        }
        for index in 1..points.len() {
            let (x0, y0) = points[index - 1];
            let (x1, y1) = points[index];
            let rank = ((layer_index + 1) * 3) as u8;
            let style = wave_trace_style(
                layer_index,
                (y1.max(0) as usize / 4).min(height.saturating_sub(1)),
                height,
                theme,
                layers.len(),
                WaveRenderMode::Heart,
            );
            for (px, py) in raster_line(x0, y0, x1, y1) {
                if px < 0 || py < 0 {
                    continue;
                }
                set_braille_pixel(
                    &mut masks,
                    &mut styles,
                    &mut ranks,
                    px as usize,
                    py as usize,
                    style,
                    rank,
                );
            }
        }
    }
    let mut lines = Vec::with_capacity(height);
    for row in 0..height {
        let spans = (0..width)
            .map(|col| Span::styled(braille_char(masks[row][col]).to_string(), styles[row][col]))
            .collect::<Vec<_>>();
        lines.push(Line::from(spans));
    }
    lines
}

fn resample_waveform(source: &[f32], width: usize) -> Vec<f32> {
    if width == 0 || source.is_empty() {
        return Vec::new();
    }
    if source.len() == 1 {
        return vec![source[0]; width];
    }
    let mut out = Vec::with_capacity(width);
    let max_index = source.len() - 1;
    for x in 0..width {
        let pos = x as f64 * max_index as f64 / width.saturating_sub(1).max(1) as f64;
        let left = pos.floor() as usize;
        let right = (left + 1).min(max_index);
        let frac = pos - left as f64;
        let a = source[left] as f64;
        let b = source[right] as f64;
        out.push((a + (b - a) * frac) as f32);
    }
    out
}

fn smooth_waveform(source: &[f32], momentum: f32) -> Vec<f32> {
    let mut out = Vec::with_capacity(source.len());
    let mut last = 0.0;
    for &sample in source {
        last = last * momentum + sample * (1.0 - momentum);
        out.push(last);
    }
    out
}

fn smooth_curve(source: &[f32]) -> Vec<f32> {
    if source.len() < 3 {
        return source.to_vec();
    }
    let mut out = Vec::with_capacity(source.len());
    for index in 0..source.len() {
        let left = source[index.saturating_sub(1)];
        let current = source[index];
        let right = source[(index + 1).min(source.len() - 1)];
        out.push((left * 0.25 + current * 0.5 + right * 0.25).clamp(-1.0, 1.0));
    }
    out
}

fn build_visual_curve(source: &[u64], width: usize, shimmer: f32, warp: f32) -> Vec<f32> {
    let sampled = resample_bars(source, width.max(8));
    let normalized = sampled
        .iter()
        .map(|v| ((*v as f32 / 100.0) * 2.0 - 1.0).clamp(-1.0, 1.0))
        .collect::<Vec<_>>();
    let filtered = smooth_waveform(&normalized, 0.76);
    let curved = smooth_curve(&filtered);
    let mut phase = 0.0f32;
    curved
        .iter()
        .enumerate()
        .map(|(index, sample)| {
            phase += 0.13 + (index as f32 % 5.0) * 0.006;
            let drift = phase.sin() * shimmer + (phase * 0.42).cos() * warp;
            (sample * 0.88 + drift).clamp(-1.0, 1.0)
        })
        .collect()
}

fn sculpt_scope_wave(source: &[f32]) -> Vec<f32> {
    if source.is_empty() {
        return Vec::new();
    }
    let mut out = Vec::with_capacity(source.len());
    let mut phase = 0.0f32;
    for (index, sample) in source.iter().copied().enumerate() {
        phase += 0.11 + (index as f32 % 7.0) * 0.002;
        let shimmer = phase.sin() * 0.08 + (phase * 0.5).cos() * 0.04;
        let curved = (sample * 0.92 + shimmer).clamp(-1.0, 1.0);
        out.push(curved);
    }
    out
}

fn amplify_columns(columns: &[u64], gain: f32, floor: f32) -> Vec<u64> {
    columns
        .iter()
        .map(|value| ((*value as f32 * gain) + floor).clamp(0.0, 100.0).round() as u64)
        .collect()
}

fn remove_dc_bias(source: &[f32]) -> Vec<f32> {
    if source.is_empty() {
        return Vec::new();
    }
    let avg = source.iter().copied().sum::<f32>() / source.len() as f32;
    source
        .iter()
        .map(|sample| (sample - avg).clamp(-1.0, 1.0))
        .collect()
}

fn soften_columns(columns: &[u64], momentum: f64) -> Vec<u64> {
    let mut smoothed = Vec::with_capacity(columns.len());
    let mut last = 0.0;
    for &column in columns {
        let current = column as f64;
        last = last * momentum + current * (1.0 - momentum);
        smoothed.push(last.round() as u64);
    }
    smoothed
}

fn scope_trace_style(
    trace_index: usize,
    row: usize,
    height: usize,
    theme: &Theme,
    trace_count: usize,
) -> Style {
    let age_mix = 1.0 - (trace_index as f32 / trace_count.max(1) as f32);
    let vertical_mix = 1.0 - ((row as f32 - (height as f32 / 2.0)).abs() / (height.max(1) as f32 / 2.0).max(1.0));
    let pulse = (age_mix * 0.78 + vertical_mix * 0.22).clamp(0.0, 1.0);
    let color = breathe_color(theme, pulse);
    let mut style = Style::default().fg(color).bg(Color::Reset);
    if trace_index == tracestrong(trace_count) {
        style = style.add_modifier(Modifier::BOLD);
    }
    style
}

fn wave_trace_style(
    trace_index: usize,
    row: usize,
    height: usize,
    theme: &Theme,
    trace_count: usize,
    mode: WaveRenderMode,
) -> Style {
    let age_mix = 1.0 - (trace_index as f32 / trace_count.max(1) as f32);
    let vertical_mix =
        1.0 - ((row as f32 - (height as f32 / 2.0)).abs() / (height.max(1) as f32 / 2.0).max(1.0));
    let mode_boost = match mode {
        WaveRenderMode::Mirror => 0.08,
        WaveRenderMode::Hills => -0.04,
        WaveRenderMode::Split => 0.03,
        WaveRenderMode::Dots => 0.12,
        WaveRenderMode::Heart => 0.18,
    };
    let pulse = (age_mix * 0.72 + vertical_mix * 0.20 + mode_boost).clamp(0.0, 1.0);
    let mut style = Style::default().fg(breathe_color(theme, pulse)).bg(Color::Reset);
    if trace_index + 1 == trace_count || pulse > 0.74 {
        style = style.add_modifier(Modifier::BOLD);
    }
    style
}

fn tracestrong(trace_count: usize) -> usize {
    trace_count.saturating_sub(1)
}

fn breathe_color(theme: &Theme, pulse: f32) -> Color {
    let base = blend_color(theme.background, theme.foreground, pulse);
    if pulse > 0.82 {
        blend_color(base, theme.secondary, (pulse - 0.82) / 0.18)
    } else if pulse > 0.62 {
        blend_color(base, theme.accent, (pulse - 0.62) / 0.20)
    } else {
        base
    }
}

fn blend_color(from: Color, to: Color, mix: f32) -> Color {
    let mix = mix.clamp(0.0, 1.0);
    match (from, to) {
        (Color::Rgb(r1, g1, b1), Color::Rgb(r2, g2, b2)) => Color::Rgb(
            lerp_u8(r1, r2, mix),
            lerp_u8(g1, g2, mix),
            lerp_u8(b1, b2, mix),
        ),
        _ => {
            if mix < 0.5 {
                from
            } else {
                to
            }
        }
    }
}

fn lerp_u8(from: u8, to: u8, mix: f32) -> u8 {
    (from as f32 + (to as f32 - from as f32) * mix).round() as u8
}

fn scope_rank(trace_index: usize, is_tip: bool) -> u8 {
    let base = (trace_index as u8 + 1) * 2;
    if is_tip {
        base + 1
    } else {
        base
    }
}

fn raster_line(x0: isize, y0: isize, x1: isize, y1: isize) -> Vec<(isize, isize)> {
    let dx = (x1 - x0).abs();
    let sx = if x0 < x1 { 1 } else { -1 };
    let dy = -(y1 - y0).abs();
    let sy = if y0 < y1 { 1 } else { -1 };
    let mut err = dx + dy;
    let mut x = x0;
    let mut y = y0;
    let mut points = Vec::new();
    loop {
        points.push((x, y));
        if x == x1 && y == y1 {
            break;
        }
        let e2 = err * 2;
        if e2 >= dy {
            err += dy;
            x += sx;
        }
        if e2 <= dx {
            err += dx;
            y += sy;
        }
    }
    points
}

fn set_braille_pixel(
    masks: &mut [Vec<u8>],
    styles: &mut [Vec<Style>],
    ranks: &mut [Vec<u8>],
    x: usize,
    y: usize,
    style: Style,
    rank: u8,
) {
    let cell_x = x / 2;
    let cell_y = y / 4;
    if cell_y >= masks.len() || cell_x >= masks[cell_y].len() {
        return;
    }
    masks[cell_y][cell_x] |= braille_dot_mask(x % 2, y % 4);
    if rank >= ranks[cell_y][cell_x] {
        ranks[cell_y][cell_x] = rank;
        styles[cell_y][cell_x] = style.bg(Color::Reset);
    }
}

fn braille_dot_mask(x: usize, y: usize) -> u8 {
    match (x, y) {
        (0, 0) => 0x01,
        (0, 1) => 0x02,
        (0, 2) => 0x04,
        (0, 3) => 0x40,
        (1, 0) => 0x08,
        (1, 1) => 0x10,
        (1, 2) => 0x20,
        (1, 3) => 0x80,
        _ => 0,
    }
}

fn braille_char(mask: u8) -> char {
    if mask == 0 {
        ' '
    } else {
        char::from_u32(0x2800 + mask as u32).unwrap_or(' ')
    }
}

#[derive(Clone, Copy)]
enum WaveRenderMode {
    Mirror,
    Hills,
    Split,
    Dots,
    Heart,
}

pub fn fetch_channels() -> Result<Vec<Channel>> {
    Ok(vec![
        channel("Ekot sänder direkt", "https://live1.sr.se/ekotdirekt-mp3-96"),
        channel("P1", "https://live1.sr.se/p1-mp3-96"),
        channel("P2", "https://live1.sr.se/p2-mp3-96"),
        channel("P3", "https://live1.sr.se/p3-mp3-96"),
        channel("P3 Din gata", "https://live1.sr.se/dingata-mp3-96"),
        channel("P4 Blekinge", "https://live1.sr.se/p4blek-mp3-96"),
        channel("P4 Dalarna", "https://live1.sr.se/p4dala-mp3-96"),
        channel("P4 Digital", "https://live1.sr.se/p4digi-mp3-96"),
        channel("P4 Gotland", "https://live1.sr.se/p4gotl-mp3-96"),
        channel("P4 Gävleborg", "https://live1.sr.se/p4gavl-mp3-96"),
        channel("P4 Göteborg", "https://live1.sr.se/p4gbg-mp3-96"),
        channel("P4 Halland", "https://live1.sr.se/p4hall-mp3-96"),
        channel("P4 Jämtland", "https://live1.sr.se/p4jmtl-mp3-96"),
        channel("P4 Jönköping", "https://live1.sr.se/p4jkpg-mp3-96"),
        channel("P4 Kalmar", "https://live1.sr.se/p4kalm-mp3-96"),
        channel("P4 Kristianstad", "https://live1.sr.se/p4krist-mp3-96"),
        channel("P4 Kronoberg", "https://live1.sr.se/p4kron-mp3-96"),
        channel("P4 Malmöhus", "https://live1.sr.se/p4malm-mp3-96"),
        channel("P4 Norrbotten", "https://live1.sr.se/p4nbtn-mp3-96"),
        channel("P4 Plus", "https://live1.sr.se/p4plus-mp3-96"),
        channel("P4 Sjuhärad", "https://live1.sr.se/p4sju-mp3-96"),
        channel("P4 Skaraborg", "https://live1.sr.se/p4skbg-mp3-96"),
        channel("P4 Stockholm", "https://live1.sr.se/p4sth-mp3-96"),
        channel("P4 Sörmland", "https://live1.sr.se/p4sorm-mp3-96"),
        channel("P4 Uppland", "https://live1.sr.se/p4uppl-mp3-96"),
        channel("P4 Värmland", "https://live1.sr.se/p4vrml-mp3-96"),
        channel("P4 Väst", "https://live1.sr.se/p4vast-mp3-96"),
        channel("P4 Västerbotten", "https://live1.sr.se/p4vbtn-mp3-96"),
        channel("P4 Västernorrland", "https://live1.sr.se/p4vnrl-mp3-96"),
        channel("P4 Västmanland", "https://live1.sr.se/p4vstm-mp3-96"),
        channel("P4 Örebro", "https://live1.sr.se/p4oreb-mp3-96"),
        channel("P4 Östergötland", "https://live1.sr.se/p4ostg-mp3-96"),
        channel("P6", "https://live1.sr.se/p6-mp3-96"),
        channel("Radioapans knattekanal", "https://live1.sr.se/knattekanalen-mp3-96"),
        channel("Sameradion", "https://live1.sr.se/sameradion-mp3-96"),
        channel("Sveriges Radio Finska", "https://live1.sr.se/finska-mp3-96"),
    ])
}

fn channel(name: &str, url: &str) -> Channel {
    Channel {
        name: name.to_string(),
        url: url.to_string(),
    }
}

fn load_alacritty_themes() -> Result<Vec<Theme>> {
    let root = home_dir().join(".config").join("alacritty");
    let mut files = Vec::new();
    collect_theme_files(&root, &mut files)?;
    let mut names = HashSet::new();
    let mut themes = Vec::new();
    for path in files {
        if let Ok(theme) = parse_theme_file(&path) {
            let key = theme.name.to_lowercase();
            if names.insert(key) {
                themes.push(theme);
            }
        }
    }
    themes.sort_by(|left, right| left.name.to_lowercase().cmp(&right.name.to_lowercase()));
    if themes.is_empty() {
        return Err(anyhow!("no Alacritty TOML themes found"));
    }
    Ok(themes)
}

fn collect_theme_files(dir: &Path, files: &mut Vec<PathBuf>) -> Result<()> {
    if !dir.exists() {
        return Ok(());
    }
    for entry in fs::read_dir(dir)? {
        let entry = entry?;
        let path = entry.path();
        if path.is_dir() {
            collect_theme_files(&path, files)?;
            continue;
        }
        let is_toml = path.extension().and_then(|ext| ext.to_str()) == Some("toml");
        let is_backup = path
            .file_name()
            .and_then(|name| name.to_str())
            .map(|name| name.contains("backup") || name.contains(".bak"))
            .unwrap_or(false);
        if is_toml && !is_backup {
            files.push(path);
        }
    }
    Ok(())
}

fn parse_theme_file(path: &Path) -> Result<Theme> {
    let text = fs::read_to_string(path)?;
    let mut section = String::new();
    let mut background = None;
    let mut foreground = None;
    let mut green = None;
    let mut blue = None;
    let mut cyan = None;
    let mut yellow = None;
    let mut magenta = None;
    let mut white = None;
    for line in text.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        if trimmed.starts_with('[') && trimmed.ends_with(']') {
            section = trimmed
                .trim_start_matches('[')
                .trim_end_matches(']')
                .to_string();
            continue;
        }
        let Some((key, raw_value)) = trimmed.split_once('=') else {
            continue;
        };
        let key = key.trim();
        let value = raw_value.trim().trim_matches('"').trim_matches('\'');
        match (section.as_str(), key) {
            ("colors.primary", "background") => background = Some(value.to_string()),
            ("colors.primary", "foreground") => foreground = Some(value.to_string()),
            ("colors.normal", "green") => green = Some(value.to_string()),
            ("colors.normal", "blue") => blue = Some(value.to_string()),
            ("colors.normal", "cyan") => cyan = Some(value.to_string()),
            ("colors.normal", "yellow") => yellow = Some(value.to_string()),
            ("colors.normal", "magenta") => magenta = Some(value.to_string()),
            ("colors.normal", "white") => white = Some(value.to_string()),
            _ => {}
        }
    }
    let background = parse_hex_color(background.as_deref())?;
    let foreground = parse_hex_color(foreground.as_deref())?;
    let accent = parse_hex_color(green.as_deref().or(blue.as_deref()).or(cyan.as_deref()))?;
    let secondary = parse_hex_color(
        yellow
            .as_deref()
            .or(magenta.as_deref())
            .or(white.as_deref()),
    )?;
    let name = path
        .file_stem()
        .and_then(|stem| stem.to_str())
        .ok_or_else(|| anyhow!("bad theme filename"))?
        .to_string();
    Ok(Theme {
        name,
        background,
        foreground,
        accent,
        secondary,
    })
}

fn parse_hex_color(value: Option<&str>) -> Result<Color> {
    let raw = value.ok_or_else(|| anyhow!("missing color string"))?;
    let hex = raw.trim().trim_start_matches('#').trim_start_matches("0x");
    if hex.len() != 6 {
        return Err(anyhow!("unsupported color format: {raw}"));
    }
    let r = u8::from_str_radix(&hex[0..2], 16)?;
    let g = u8::from_str_radix(&hex[2..4], 16)?;
    let b = u8::from_str_radix(&hex[4..6], 16)?;
    Ok(Color::Rgb(r, g, b))
}

fn load_persisted_config() -> PersistedConfig {
    let path = config_path();
    let text = match fs::read_to_string(path) {
        Ok(text) => text,
        Err(_) => return PersistedConfig::default(),
    };
    toml::from_str(&text).unwrap_or_default()
}

fn save_persisted_config(config: &PersistedConfig) -> Result<()> {
    let path = config_path();
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
    }
    let text = toml::to_string(config)?;
    fs::write(path, text)?;
    Ok(())
}

fn home_dir() -> PathBuf {
    std::env::var_os("HOME")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("/tmp"))
}

fn config_path() -> PathBuf {
    home_dir()
        .join(".config")
        .join("srtui")
        .join("config.toml")
}

fn setup_terminal() -> Result<Terminal<CrosstermBackend<Stdout>>> {
    crossterm::terminal::enable_raw_mode()?;
    let mut stdout = std::io::stdout();
    crossterm::execute!(
        stdout,
        crossterm::terminal::EnterAlternateScreen,
        crossterm::event::EnableMouseCapture
    )?;
    let backend = CrosstermBackend::new(stdout);
    Ok(Terminal::new(backend)?)
}

fn restore_terminal(mut terminal: Terminal<CrosstermBackend<Stdout>>) -> Result<()> {
    crossterm::terminal::disable_raw_mode()?;
    crossterm::execute!(
        terminal.backend_mut(),
        crossterm::event::DisableMouseCapture,
        crossterm::terminal::LeaveAlternateScreen
    )?;
    terminal.show_cursor()?;
    Ok(())
}
