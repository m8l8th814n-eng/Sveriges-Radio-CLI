# srtui

`srtui` is a Rust terminal app for listening to Sveriges Radio.

## Features

- built-in Sveriges Radio channel list
- TUI with nerd-font icons
- multiple braille-based visualizers
- volume and pause control
- 10, 20 or 30 second rewind buffer
- recording to `~/Music` in `mp3`, `flac`, `ogg` or `wav`
- Alacritty theme loading with persisted theme and visualizer selection

## Build

```bash
cargo build --bin srtui
```

## Run

```bash
cargo run --bin srtui
```

## Controls

- `Up/Down` or `j/k`: move in the channel list
- `Enter`: start playback
- `Space`: pause
- `+` / `-`: volume
- `1` / `2` / `3`: rewind by 10 / 20 / 30 seconds
- `l`: jump back to live
- `r`: toggle recording
- `t` / `T`: switch theme
- `v`: switch visualizer
- `m`: switch recording format
- `q`: quit

## Recording

Recordings are written to:

```text
~/Music
```

The current implementation can record as `.mp3`, `.flac`, `.ogg` or `.wav`.

## Project Layout

- `src/bin/srtui.rs`: binary entrypoint
- `src/radio.rs`: TUI and audio engine
- `PKGBUILD`: Arch Linux packaging
